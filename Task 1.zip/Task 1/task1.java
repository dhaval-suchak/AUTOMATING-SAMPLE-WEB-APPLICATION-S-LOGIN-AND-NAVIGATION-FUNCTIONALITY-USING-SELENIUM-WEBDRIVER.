package seleniumautomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class task1 {

	public static void main(String[] args) {
		
	System.setProperty("webdriver.chrome.driver","C:\\Selenium Webdriver\\Chrome Driver\\chromedriver-win64\\chromedriver.exe")	;	
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.linkedin.com/feed/");
		

		try {
			Thread.sleep(2000); 
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		driver.findElement(By.id("username")).sendKeys("hellooo07071981@gmail.com");
		driver.findElement(By.id("password")).sendKeys("hello@070707");
		driver.findElement(By.xpath("//*[@id=\"organic-div\"]/form/div[4]/button")).click();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		String u = driver.getCurrentUrl();
		
		if (u.contains("/feed/")) {
			System.out.println("✅ Login successful");

		
			assert u.contains("/feed/");
		} else {
			System.out.println("❌ Login failed or did not reach home page");
		}
		
		
		driver.quit();
		

	}

}
